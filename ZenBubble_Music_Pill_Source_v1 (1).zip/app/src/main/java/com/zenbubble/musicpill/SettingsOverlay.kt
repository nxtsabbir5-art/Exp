package com.zenbubble.musicpill

import android.content.Context
import android.provider.Settings

object SettingsOverlay {
    fun allowed(context: Context): Boolean = Settings.canDrawOverlays(context)
}
