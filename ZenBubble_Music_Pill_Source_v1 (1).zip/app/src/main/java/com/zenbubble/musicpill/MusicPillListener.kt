package com.zenbubble.musicpill

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView

class MusicPillListener : NotificationListenerService() {
    private var windowManager: WindowManager? = null
    private var pillView: LinearLayout? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var playPauseButton: ImageButton? = null
    private var mediaController: MediaController? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        activeNotifications?.forEach(::inspectNotification)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        inspectNotification(sbn)
    }

    private fun inspectNotification(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val token = if (Build.VERSION.SDK_INT >= 33) {
            extras.getParcelable(android.app.Notification.EXTRA_MEDIA_SESSION, MediaSession.Token::class.java)
        } else {
            @Suppress("DEPRECATION")
            extras.getParcelable<MediaSession.Token>(android.app.Notification.EXTRA_MEDIA_SESSION)
        } ?: return

        try {
            mediaController = MediaController(this, token)
            showPill()
            updatePill()
        } catch (_: Exception) {
            // Ignore invalid or expired media sessions.
        }
    }

    private fun showPill() {
        if (pillView != null || !SettingsOverlay.allowed(this)) return

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 8, 10, 8)
            background = GradientDrawable().apply {
                setColor(Color.rgb(10, 10, 14))
                cornerRadius = 100f
                setStroke(2, Color.rgb(105, 75, 190))
            }
        }

        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        titleView = TextView(this).apply {
            text = "Now playing"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        artistView = TextView(this).apply {
            text = "Music"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            maxLines = 1
        }
        textColumn.addView(titleView)
        textColumn.addView(artistView)

        playPauseButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_pause)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.rgb(190, 160, 255))
            contentDescription = "Play or pause"
            setOnClickListener { togglePlayback() }
        }
        val nextButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.WHITE)
            contentDescription = "Next track"
            setOnClickListener { mediaController?.transportControls?.skipToNext() }
        }

        container.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
        container.addView(playPauseButton, LinearLayout.LayoutParams(44, 44))
        container.addView(nextButton, LinearLayout.LayoutParams(44, 44))
        pillView = container

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 28
        }

        try {
            windowManager?.addView(container, params)
        } catch (_: Exception) {
            pillView = null
        }
    }

    private fun updatePill() {
        val controller = mediaController ?: return
        val metadata: MediaMetadata? = controller.metadata
        titleView?.text = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: controller.packageName
        artistView?.text = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: "Now playing"

        val isPlaying = controller.playbackState?.state == PlaybackState.STATE_PLAYING
        playPauseButton?.setImageResource(
            if (isPlaying) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play
        )
    }

    private fun togglePlayback() {
        val controller = mediaController ?: return
        if (controller.playbackState?.state == PlaybackState.STATE_PLAYING) {
            controller.transportControls.pause()
        } else {
            controller.transportControls.play()
        }
        pillView?.postDelayed({ updatePill() }, 300)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Keep the pill until another session replaces it; media apps may remove notifications briefly.
    }

    override fun onDestroy() {
        try {
            pillView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        pillView = null
        super.onDestroy()
    }
}
