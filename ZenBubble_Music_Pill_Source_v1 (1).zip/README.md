# ZenBubble Music Pill

A minimal Android floating music-control pill.

## Build an APK with GitHub Actions

1. Create a new empty GitHub repository.
2. Extract this ZIP on your phone or computer.
3. Upload the **contents** of the extracted folder to the repository root. Do not upload the ZIP itself.
4. Open the repository's Actions tab.
5. Wait for **Build ZenBubble Music Pill** to finish successfully.
6. Open the successful run, find Artifacts, and download `ZenBubble-Music-Pill-debug`.
7. Extract the artifact ZIP to get `app-debug.apk`.

## First launch

1. Install and open the app.
2. Tap **Allow display over other apps** and grant the permission.
3. Tap **Enable music notification access** and enable ZenBubble.
4. Start music in a media app.

The pill appears at the top when Android provides a media-session notification. It shows the track title and artist, with play/pause and next controls.

## Notes

- Android 8.0 (API 26) or newer.
- This starter version does not stream or download music.
- Some Android manufacturers may require enabling autostart/background activity.
- Album artwork and waveform animation are not included in this first build.
